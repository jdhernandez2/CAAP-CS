#!/bin/sh
# For Mac Users, to make the executable file of the game.
pyinstaller --onefile game.py --name mygame